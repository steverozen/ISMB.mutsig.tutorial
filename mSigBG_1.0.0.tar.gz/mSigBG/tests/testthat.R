library(testthat)
library(mSigBG)

test_check("mSigBG")
