# mSigBG

Separate a "background mutational signature" from a set of observed mutational
spectra. Designed for the delineation of signatures from cell cultures exposed 
to mutagens. 

'mSigBG' stands for "**m**utational **Sig**nature **B**ack**G**round".
