
<!-- README.md is generated from README.Rmd. Please edit that file -->
PCAWG7
======

Purpose
-------

Package with data from from Alexandrov, Kim, Haradhvala, Huang et al., 'Repertoire of Mutational Signatures in Human Cancer'. Still a work in progress, so not all data from the paper are available. Contact the author with requests.

Installation
------------

Install PCAWG7 from the master branch on [GitHub](https://github.com/):

``` r
install.packages("devtools")
devtools::install_github("steverozen/PCAWG7")
```
