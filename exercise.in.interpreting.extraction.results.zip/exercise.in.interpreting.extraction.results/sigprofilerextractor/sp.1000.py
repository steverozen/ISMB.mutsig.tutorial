from sigproextractor import sigpro as sig

# import pdb

# pdb.run('

sig.sigProfilerExtractor(input_type = "table", 
                         out_put = "sig.pro.output", 
                         input_data = "../3.types.ground.truth.spectra.1000.size.sigpro.txt", 
                         startProcess = 9,  
                         endProcess  = 17,
                         totalIterations = 1000, 
                         cpu = 20, 
                         hierarchy = False, 
                         mtype = "96", 
                         exome = False, 
                         resample = True)

# ')

# nice python3 sp.1000.py > out &> err &
