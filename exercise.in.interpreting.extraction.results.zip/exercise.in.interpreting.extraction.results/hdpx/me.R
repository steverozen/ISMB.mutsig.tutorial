# Example script for running RunAndEvalHdp4 in "production" mode with valgrind
# ! Put this script in its own directory;
# all the output goes to the current working directory.

root.dir <- ".."

library(hdpx)
library(mSigHdp)

retval <- RunHdpParallel(
  input.catalog    = file.path(root.dir,
                                    "3.types.ground.truth.spectra.1000.size.csv"),
  ground.truth.exp = file.path(root.dir,
                                    "3.types.ground.truth.exposures.1000.size.csv"),
  ground.truth.sig = file.path(root.dir,
                                    "ground.truth.syn.sigs.csv"),
  out.dir               = ".",
  CPU.cores             = 20,
  seedNumber            = 7744,
  K.guess               = 20,
  post.burnin           = 20000,
  post.n                = 500,
  post.space            = 50,
  multi.types           = TRUE, ###### !
  overwrite             = TRUE,
  num.child.process     = 20,
  one.parent.hack       = TRUE)

# nice /opt/R/R-4.0.0/bin/exec/R --vanilla < me.R >out &>err &

